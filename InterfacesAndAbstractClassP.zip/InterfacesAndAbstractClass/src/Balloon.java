
public class Balloon implements Aircraft {

	private int altitude; 

	public String name;// not implemented on hw
	public Balloon() {
		
		this.altitude = 0;
		
	}
	public Balloon(String name, int altitude) { // not in form
		
		//super(name);
		this.name = name;
		this.altitude = altitude;
	}

	public Balloon(int Altitude) {
		setAltitude(Altitude);
		
	}
	
	
	@Override
	public String toString() {
		return "Balloon [altitude=" + altitude + ", name=" + name + "]";
	}
	public int getAltitude() {
		return altitude;
	}

	public void setAltitude(int altitude) {
		this.altitude = altitude;
	}

	@Override
	public void increaseAltitude(int increment) {
		// TODO Auto-generated method stub
		this.altitude += increment;
	}

	@Override
	public void decreaseAltitude(int decrement) {
		// TODO Auto-generated method stub
		this.altitude -= decrement;
	}
	
}
