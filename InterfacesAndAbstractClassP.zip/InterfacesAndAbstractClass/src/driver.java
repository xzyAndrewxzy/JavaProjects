import java.util.ArrayList;
public class driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Balloon hotair = new Balloon("Hot air ",0);
				
		Airplane censna = new Airplane("Red Cesna", 0);
		 
		
		Jet bluejet = new Jet("Blue Jet","F/A-18 Hornet", 70);
		System.out.println(hotair);
		
		System.out.println();
		ArrayList<Aircraft> list = new ArrayList<Aircraft>();
		
		list.add(bluejet);
		list.add(censna);
		list.add(hotair);
		
		for(Aircraft things: list) {
			
			System.out.println(things);
			things.increaseAltitude(100);
			//things.decreaseAltitude(decrement);
			System.out.print(things);
		}
		
	}
	// needs 6

}






// absrtact
// super
// java inhere