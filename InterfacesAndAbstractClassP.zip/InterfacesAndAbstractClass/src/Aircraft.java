
public interface Aircraft {

	public void increaseAltitude(int increment);
	
	public void decreaseAltitude(int decrement);
	
}
