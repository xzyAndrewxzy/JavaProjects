
public class Jet extends Airplane {

	private String model;
	
	public Jet() {
		super();
	}
	
	public Jet(String name, int altitude, int aircraftcount,String model) {
		super(name,altitude,aircraftcount);
		setModel(model);
	}

	public Jet(String name, String name2, int i) {// ???
		// TODO Auto-generated constructor stub
		super(i);
		setName(name);
		setModel(name2);
		
		
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	@Override
	public String toString() {
		return "Jet [model=" + model + ", name=" + name + ", altitude=" + altitude + ", getName()=" + getName()
				+ ", getAltitude()=" + getAltitude() + ", toString()=" + super.toString() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + "]";
	}
	
}
