
public class Airplane implements Aircraft {

	protected String name;
	protected int altitude;
	protected static int aircraftcount;
	
	public Airplane() {
		
		
		this.aircraftcount += this.aircraftcount + 1;
	}
	public Airplane(String name, int altitude, int aircraftcount) {
		
		setName(name);
		setAltitude(altitude);
		setAircraftcount(aircraftcount);
		
		this.aircraftcount += this.aircraftcount + 1;
	}
	
	
	public Airplane(String string, int i) {
		// TODO Auto-generated constructor stub
		setName(string);
		
	}
	public Airplane(int i) {
		
		setAltitude(i);
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAltitude() {
		return altitude;
	}
	public void setAltitude(int altitude) {
		this.altitude = altitude;
	}
	public static int getAircraftcount() {
		return aircraftcount;
	}
	public static void setAircraftcount(int aircraftcount) {
		Airplane.aircraftcount = aircraftcount;
	}
	@Override
	public void increaseAltitude(int increment) {
		// TODO Auto-generated method stub
		altitude += increment;
	}
	@Override
	public void decreaseAltitude(int decrement) {
		// TODO Auto-generated method stub
		altitude -= decrement;
	}
	@Override
	public String toString() {
		return "Airplane [name=" + name + ", altitude=" + altitude + "]";
	}

	
}
