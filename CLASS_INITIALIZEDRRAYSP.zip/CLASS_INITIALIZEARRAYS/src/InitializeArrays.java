import java.util.Scanner;
import java.util.Random;
import java.util.Arrays;

public class InitializeArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in);
		float [] temps = {211.0f,32.0f,98.6f,72.56f,101.4f};
		int sold[] = new int[5];
		float [] dataPoints = new float[10];
		Random r = new Random();
		
		for (int index = 0; index < dataPoints.length; index++) {
			
			dataPoints[index] = r.nextFloat(); // give index random value
			System.out.printf("DataPoints [%d] = %f \n", index,dataPoints[index]);
				
		}
		Arrays.sort(dataPoints); // quickSort of the elements
		for (float data1 : dataPoints) {
			//  for each construct; access each element in the array
			System.out.printf("%f\n", data1);
			
		}
		for (int index = 0; index <temps.length; index++) {
			System.out.printf("%5.2f  ", temps[index]);
			
			}
		
		System.out.println("\n");
		
		String strTemps = Arrays.toString(temps);
		System.out.println(strTemps);
		
		System.out.println("Enter the element to search for");
		float findTemp = input.nextFloat(); // element to find
		int matchIndex = myLinearSearch(temps,findTemp);
		
		if (matchIndex >=0) {
			System.out.println("match found at index"+matchIndex);
			
			
		} else {
			System.out.println("no match found");
			System.out.println("index = " +matchIndex);
			
			
		}
		for (int index = 0; index <sold.length; index++) {
			
			System.out.printf("Enter the items sold \n");
			sold[index]= input.nextInt();
			}
		int totalSold = 0;
		for (int index =0; index < sold.length; index++) {
			totalSold += sold[index];
			
		}
		
		System.out.printf("totalSold = %d \n", totalSold);
		
		float average = findAverage(temps);
		System.out.printf("The average is %f \n", average);
		
		float temps2[] = new float [temps.length];
		temps2 = copyArray(temps);
		printArray(temps, "temps");
		printArray(temps2, "temps");
		
		float[] a = new float[3];
		float[] b = new float [5];
		float[] c = new float [2];
		
		initArrays(a,b,c,3.5f);
		printArray(a,"a");
		printArray(b,"b");
		printArray(c,"c");
		
		input.close();
		
		
		
	}// end of main

	static void initArrays(float a1[],float b1[], float c1[], float x) {
		
		// arrays are always pass by reference
		for (int i =0; i < a1.length; i++) {
			a1[i] = x;
		} 
		for (int i =0; i < b1.length; i++) {
			b1[i] = x;
		} 
		for (int i =0; i < c1.length; i++) {
			c1[i] = x;
		} 
		
		
	}// initArrays
	
	static float[] copyArray (float array1[]) {
		float [] c = new float [array1.length];
		for (int i =0; i <array1.length;i++) {
			c[i] = array1[i];
		}
		return c;
	}// end of copyArray method
	static void printArray(float array1[], String arrayName) {
		for (int i = 0; i < array1.length;i++) {
			System.out.printf("%s [%d] =  %f \n", arrayName, i , array1[i]);
			
		}// end of for loop
		
	}// end of PrintArray method
	
	static float findAverage(float array1[]) {
		float avg, sum = 0.0f;
		
		for(int index = 0; index < array1.length; index++) {
			sum = sum + array1[index];
			}
			avg = sum/array1.length;
			return avg;
			}// end of FindAverage
	
	static int myLinearSearch(float array1[], float search) {
		int matchIndex = -1;
		
		for ( int i = 0; i < array1.length; i++) {
			
			if (Math.abs(array1[i]-search)< 0.001f) {
				
				matchIndex = i;
				
			}// end of IF
			}//end of LOOP
		return matchIndex;
	}// end of MylinearSearchMethod
	
}// end of InitializeArrays
