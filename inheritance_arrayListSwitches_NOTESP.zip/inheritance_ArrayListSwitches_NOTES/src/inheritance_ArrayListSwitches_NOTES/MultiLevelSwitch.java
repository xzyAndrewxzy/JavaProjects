package inheritance_ArrayListSwitches_NOTES;

public class MultiLevelSwitch implements Switchable, Knob{
	private boolean set = false;
	private int value = 0;
	private boolean state = false;

	
	@Override
	public int getLevel() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setLevel(int level) {
		// TODO Auto-generated method stub
		
	}

	
	//  FROM SWITCHABLE
	@Override
	public boolean getState() {
		// TODO Auto-generated method stub
		return state;
	}

	@Override
	public void setState(boolean s) {
		// TODO Auto-generated method stub
		if ((value > 0)&& s){ // S is by default false
			state = true;
			
		}else {
			state = false;
		}
	}
	
	
	
}