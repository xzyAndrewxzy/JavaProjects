package inheritance_ArrayListSwitches_NOTES;


public class Switch implements Switchable{

	private boolean set;

	@Override
	public boolean getState() {
		// TODO Auto-generated method stub
		return set;
	}

	@Override
	public void setState(boolean s) {
		// TODO Auto-generated method stub
		set = s;
	}
	
	
	
	
	
}// end of SWITCH CLASS

