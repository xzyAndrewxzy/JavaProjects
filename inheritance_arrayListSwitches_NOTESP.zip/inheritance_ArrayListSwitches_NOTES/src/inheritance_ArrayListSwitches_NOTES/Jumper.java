package inheritance_ArrayListSwitches_NOTES;

//public class Jumper implements Switchable {
//	private boolean inPlace = true;
//
//	@Override
//	public boolean getState() {
//		// TODO Auto-generated method stub
//		return false;
//	}
//
//	@Override
//	public void setState(boolean s) {
//		// TODO Auto-generated method stub
//		
//	}
//	
//}


public class Jumper implements Switchable {
	private boolean inPlace = true;
	@Override
	public boolean getState() {
		// TODO Auto-generated method stub
		return inPlace ;
	}

	@Override
	public void setState(boolean s) {
		// TODO Auto-generated method stub
		inPlace = s;
	}

}
