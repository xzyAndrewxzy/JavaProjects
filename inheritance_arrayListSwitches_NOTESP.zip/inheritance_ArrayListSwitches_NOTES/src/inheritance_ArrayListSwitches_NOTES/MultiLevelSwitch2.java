package inheritance_ArrayListSwitches_NOTES;

public class MultiLevelSwitch2 implements Controller{

	private boolean set = false;
	private int value = 0;
	private boolean state = false;
	
	@Override
	public boolean getSettings() {
		// TODO Auto-generated method stub
		return state;
	}

	@Override
	public boolean getState() {
		// TODO Auto-generated method stub
		return state;
	}

	@Override
	public void setState(boolean s) {
		// TODO Auto-generated method stub
		if ((value <= MAX_LEVEL) && s){
			state = s;
		}else {
			state = false;
		}
	}

	@Override
	public int getLevel() {
		// TODO Auto-generated method stub
		return value;
	}

	@Override
	public void setLevel(int level) {
		// TODO Auto-generated method stub
		if (level <= MAX_LEVEL){
			value = level;
		} else {
			value = MAX_LEVEL;
		}
		
	}

	
	
}
