package inheritance_ArrayListSwitches_NOTES;
import java.util.ArrayList;
import java.util.Scanner;
public class SwitchDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Knob> knobList = new ArrayList<Knob>();
		
//		for(int num : knoblist) {
//			System.out.println(" "+ knobList.get(num).getLevel());
//		}
		
		
		ArrayList<Switchable> switchesList = new ArrayList<Switchable>();
		
		
		// intualizing all the classes
		Jumper j1 = new Jumper();
		
		Switch sw1 = new Switch();
		
		DipSwitch ds1 = new DipSwitch();
		
		MultiLevelSwitch mls1 = new MultiLevelSwitch();
		
		
		switchesList.add(j1);
		switchesList.add(sw1);
		switchesList.add(ds1);
		switchesList.add(mls1);
		
		for (int i = 0; i < switchesList.size(); i++) {
			System.out.println("State  " + switchesList.get(i).getState());
			//System.out.println("\n");
			
			if(switchesList.get(i) instanceof Knob) {
				
				((Knob) (switchesList.get(i))).setLevel(10);
				
				System.out.println("Level " + ((Knob) ( switchesList.get(i))).getLevel() );
				
			}
			
		}
		
		if (j1 instanceof Switchable) {
			System.out.println("  j1 is a Switchable object");
			
		}
		
		if ( ds1 instanceof Switchable) {
			System.out.println("  ds1 is a switchable object");
			
		}
		if (ds1 instanceof Switch) {
			System.out.println("  ds1 is a switch object");
		}
		if(ds1 instanceof DipSwitch) {
			System.out.println("  ds1 is a DipSwitch object");
		}
	}

}
