package inheritance_ArrayListSwitches_NOTES;

public interface Switchable {
	abstract public boolean getState();
	abstract public void setState(boolean s);
	
}

