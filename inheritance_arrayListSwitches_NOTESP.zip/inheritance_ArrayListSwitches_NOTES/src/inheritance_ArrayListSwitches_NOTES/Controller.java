package inheritance_ArrayListSwitches_NOTES;

public interface Controller extends Switchable, Knob {
	abstract public boolean getSettings();
}
