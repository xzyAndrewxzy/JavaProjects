package inheritance_ArrayListSwitches_NOTES;

public interface Knob {
	abstract public int getLevel();
	abstract  void setLevel(int level);
	public final int MAX_LEVEL = 10;
	
	
}

