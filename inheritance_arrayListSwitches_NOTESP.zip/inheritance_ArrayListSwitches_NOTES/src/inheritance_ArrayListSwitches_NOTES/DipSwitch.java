package inheritance_ArrayListSwitches_NOTES;


public class DipSwitch extends Switch{
	private boolean setting = false;
	
public boolean getState() {
		
		return setting;
	}
	
	public void setState(boolean setting) {
		
		this.setting = setting;
		
	}
	
	
	
}