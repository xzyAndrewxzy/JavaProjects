
public class Contractor {

	private String name;
	private int number;
	private int startDay,startMonth,startYear;
	public static final int currentYear = 2018;
	//(public/private) static final TYPE NAME = VALUE;
	
	static int totalContractors =0;

	public Contractor() {
		
		this.name = " Unkown" ;
		this.number = 0;
		this.startDay = 1;
		this.startMonth = 1;
		this.startYear = 2018;
		
	}
	
	public Contractor(String name, int number, int startDay, int startMonth,int startYear) {
		setName(name);
		setNumber(number);
		setStartDay(startDay);
		setStartMonth(startMonth);
		setStartYear(startYear);
		FuncTotalContactors();
	}
	
	public Contractor(String name, int number) {
		setStartDay(1);
		setStartMonth(1);
		setStartYear(2018);
		FuncTotalContactors();
	}
// func
	public static int FuncTotalContactors() {
		int totalCon = totalContractors += 1;
		return totalCon;
	}
	// func 
	float pay;
	public static int getTotalContractors() {
		return totalContractors;
	}
	public static void setTotalContractors(int totalContractors) {
		Contractor.totalContractors = totalContractors;
	}
	public float getPay() {
		return pay;
	}
	public void setPay(float pay) {
		this.pay = pay;
	}
	public float computePay() {
		
		float payRate;
		int numHolder = currentYear - startYear;
		if (currentYear - startYear >= 10) {
			payRate = 20.50f;
			pay = payRate * 40;
		} else if (numHolder > 5 && numHolder <10) {
			payRate = 15.45f;
			pay= payRate * 40;
		}else {
			payRate = 12.90f;
			pay = payRate * 40;
			
		}
			
		
		
		
		return pay;
	}
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getNumber() {
		return number;
	}


	public void setNumber(int number) {
		this.number = number;
	}


	public int getStartDay() {
		return startDay;
	}


	public void setStartDay(int startDay) {
		this.startDay = startDay;
	}


	public int getStartMonth() {
		return startMonth;
	}


	public void setStartMonth(int startMonth) {
		this.startMonth = startMonth;
	}


	public int getStartYear() {
		return startYear;
	}


	public void setStartYear(int startYear) {
		this.startYear = startYear;
	}
	
	public static int getCurrentyear() {
		return currentYear;
	}
	
	
	
	
	
	@Override
	public String toString() {
		return "Contractor [name=" + name + ", number=" + number + ", startDay=" + startDay + ", startMonth="
				+ startMonth + ", startYear=" + startYear + "]";
	}
	
}
