import java.util.ArrayList;
public class UseContractors {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Contractor seniorContractor = new Contractor("joan",25,7,5,2004);
		
		System.out.println(seniorContractor);
		
		Contractor juniorContractor = new Contractor();
		juniorContractor.setName("Mike");
		juniorContractor.setNumber(125);
		juniorContractor.setStartDay(7);
		juniorContractor.setStartYear(2010);
		System.out.println(juniorContractor);
		
		System.out.println(juniorContractor.FuncTotalContactors());
		
		System.out.println(juniorContractor.computePay());
		
		Subcontractor sub = new Subcontractor("toni",125,11,5,1998,30, 1);
		 
		float pay = sub.computePay();
		
	// needs list
		
		System.out.println("object added into list");
		ArrayList<Contractor> list = new ArrayList<Contractor>();
		System.out.println();
		list.add(seniorContractor);
		list.add(juniorContractor);
		list.add(sub);
		
		for(Contractor things : list) {
			
			//System.out.println("%s ", list.get(things));
			
			System.out.println(things);
			
		}
	
	
	}
// done
}
