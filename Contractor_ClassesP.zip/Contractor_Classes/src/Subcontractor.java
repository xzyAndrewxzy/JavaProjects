
public class Subcontractor extends Contractor {

	int hoursWorked;
	int shift;
	float totalPay;
	public Subcontractor() {
		this.hoursWorked = 40;
		this.shift = 1;
		
	}
	public Subcontractor( String name, int number, int startDay,
			int startMonth, int startYear, int hoursWorked, int shift ) {
		
		super(name,number,startDay,startMonth,startYear);
		setHoursWorked(hoursWorked);
		setShift(shift);
		
	}

	public int getHoursWorked() {
		return hoursWorked;
	}

	public void setHoursWorked(int hoursWorked) {
		if (hoursWorked <20 || hoursWorked >50) {
		this.hoursWorked = hoursWorked;
		
		}else {
			System.out.println("hours out of range setting to 40");
			this.hoursWorked = 40;
		}
	}

	// Func OverRide ComputePay
	 
	
	public float  computePay() {
		
	float payRate = 0;
	
	 float startYear = getStartYear();
	 float  currentYear = getCurrentyear();
	//float payRate = getPayRate();
	 if(shift == 0) {
			
		 payRate += 5.25f;
		
	 }
	 
	 if (startYear - currentYear >=10) {
		 payRate += 20.50f;
		
		totalPay = payRate * hoursWorked;
		
	}	else if( startYear - currentYear >=5 
			&& startYear -currentYear < 10) {
		payRate += 15.45f;
		totalPay = payRate * hoursWorked;
	} else {
		payRate += 12.90f;
		totalPay = payRate * hoursWorked;
	}
	 
		return totalPay;
		
	}
	
	
	
	
	public int getShift() {
		return shift;
	}

	public void setShift(int shift) {
		if(shift == 0 || shift ==1) {
			this.shift = shift;
		}else {
			System.out.println("invaled seting value to 1 ");
			this.shift = 1;
		}
	}

	
}
