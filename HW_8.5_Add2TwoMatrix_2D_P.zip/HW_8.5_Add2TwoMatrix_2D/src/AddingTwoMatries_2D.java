import java.util.Scanner;
public class AddingTwoMatries_2D {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in);
		
		float matrix1[][] = new float[3][3];
		
		float matrix2[][]= new float [3][3];
		
		float matrix[][] = new float [3][3];
		
	for(int rowm1 =0, rowm2 =0; rowm1 < matrix1.length ||rowm2<matrix2.length; rowm1++ ,rowm2++) { 
	for(int colm1 = 0, colm2 = 0; colm1 < matrix1[rowm1].length ||colm2<matrix2[rowm2].length; colm1++ ,colm2++){
		System.out.printf(" enter for matrix 1 at row %d and column %d \n", rowm1, colm1);
		matrix1[rowm1][colm1] = input.nextFloat();
		System.out.printf(" enter for matrix 2 row %d and column %d\n", rowm2, colm2);
		matrix2[rowm2][colm2] = input.nextFloat();		
		
		
		
				
			}
		}
		
		
	for(int rowm1 =0, rowm2 =0; rowm1 < matrix1.length ||rowm2<matrix2.length; rowm1++ ,rowm2++) { 
		for(int colm1 = 0, colm2 = 0; colm1 < matrix1[rowm1].length ||colm2<matrix2[rowm2].length; colm1++ ,colm2++){
				
			
			matrix[rowm1][colm1] = matrix1[rowm1][colm1] + matrix2[rowm2][colm2];
			System.out.print(matrix[rowm1][colm1]+" \t ");
					
				}
			System.out.println();
			}
		
		
		
	/*	for(int row = 0; row<matrix1.length; row++) {
			for(int col = 0; col< matrix1[row].length; col++) {
				
				matrix1[row][col] = input.nextFloat();
				
			}
			
		}
			for(int row = 0; row<matrix1.length; row++) {
				for(int col = 0; col<matrix2[row].length;col++) {
					
					matrix2[row][col] = input.nextFloat();
					
					
				}
				
			}
			
		
		
		
		//float inMatrix1 = inputToMatrix(matrix1);
		
		//float inMatrix2 = inputToMatrix(matrix2);
		
		
		
		
		*/
		
	}
	
	/*public static float inputToMatrix(float e[][]) {
		
		for(int row = 0; row<e.length; row++) {
			for(int col = 0; col< e[row].length; col++) {
				
				e[row][col] = input.nextFloat;
				
			}
			
		}
		 e[row][col];
		
	}*/
	

}
