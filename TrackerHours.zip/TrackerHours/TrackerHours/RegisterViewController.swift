//
//  RegisterViewController.swift
//  TrackerHours
//
//  Created by user145527 on 12/3/18.
//  Copyright © 2018 user145527. All rights reserved.
//

import UIKit
import Firebase
class RegisterViewController: UIViewController {

    @IBAction func backButton(_ sender: AnyObject) {
        dismiss(animated: true, completion: nil)
    }
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBAction func createUserButton(_ sender: AnyObject) {
        Auth.auth().createUser(withEmail: emailTextField.text!, password: passwordTextField.text!) { (user, error) in
            if error != nil{
                print(error!)
                print("there was something wrong")
                
            }else{
                if let goToHours = self.storyboard?.instantiateViewController(withIdentifier: "idToHours") as? HoursViewController{
                    goToHours.dateArray = ["testR", "dataR","passedR"]
                    
                    
                   self.present(goToHours, animated: true)
                }
                
                
            }
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
}
