//
//  HoursViewController.swift
//  TrackerHours
//
//  Created by user145527 on 12/3/18.
//  Copyright © 2018 user145527. All rights reserved.
//

import UIKit
import Firebase
class HoursViewController: UIViewController, UISearchBarDelegate, UITableViewDelegate,UITableViewDataSource {
    
    
    var DateArray : [DateForTable] = [DateForTable]()
    
    var TimeArray : [HoursList] = [HoursList]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.reloadData()
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return dateArray.count
    }
    
    
   var dateArray : [String] = ["pass"]
   //{
//
//
//        didSet{
//
//
//            }
//
//
//    }
    

    

    
     
        
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        
        
        
        
        cell!.textLabel?.text = dateArray[indexPath.row]
        
        return cell!
    }
    
    // MARK: DID select cell from table view
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var searchBar: UISearchBar!// not connected
    
    func getTime() -> String {
        let date = DateFormatter()
        
        date.dateStyle = .full    // info retrived 1
        date.timeStyle = .medium      // info retrived 2
        let time = date.string(from: Date()) // puts information into one var
        
        
        
        
        return time
        
        
    }
    
    @IBOutlet weak var clockInLabel: UILabel!
    
    @IBOutlet weak var breakOutLabel: UILabel!
    
    @IBOutlet weak var breakInLabel: UILabel!
    
    @IBOutlet weak var clockOutLabel: UILabel!
    
    
    // Mark: buton to logout
    @IBAction func logoutButton(_ sender: UIButton) {
        do{
            try Auth.auth().signOut()
            print("logout passed")
            
            
            
        } catch{
            print(" error ")
        }
        if let allowLogout = self.storyboard?.instantiateViewController(withIdentifier: "MainView") as? ViewController{
            
            present(allowLogout, animated: true)
            
        }
     
    }
    
    // Mark: button Hours
    @IBAction func ClockInButton(_ sender: UIButton) {
        
        let time = getTime()
        
        clockInLabel.text = time
        sender.isEnabled = false
        //clockInLabel.isEnabled = false
        let timeDB = Database.database().reference().child("Hours")
        let timeData = ["User" : Auth.auth().currentUser?.email,"ClockInTime" : clockInLabel.text ]
        
        timeDB.childByAutoId().setValue(timeData){(error,reference) in
            
            if error != nil{
                print("error sendinf clockIn \(error!)")
            }else{
                print("clocking time succfull")
              //  self.retrieveDateForTable()
                // give time here for button to become enable
                // and clear clockin label for the next day
            }
            
        }
        
    }
    
//    func retrieveDateForTable() {
//
//        let timeDB = Database.database().reference().child("Hours")
//
//        timeDB.observe(.childAdded) { (DataSnapshot) in
//
//            let dataSnapShot = DataSnapshot.value as! Dictionary<String,String>
//
//            let date = dataSnapShot["ClockInTime"]!
//
//            let addingDate = DateForTable()
//            addingDate.dateView = date
//            self.dateArray.append(date)
//
//        }
//        //tableView.reloadData()
//    }
    
    
    
    @IBAction func BreakOutButton(_ sender: UIButton) {
        
        let time = getTime()
        breakOutLabel.text = time

      
        
    }
    
    @IBAction func BreakInButton(_ sender: UIButton) {
        
        let time = getTime()
        breakInLabel.text = time
        
    }
    
    @IBAction func ClockOutButton(_ sender: UIButton) {
        
        let time = getTime()
        clockOutLabel.text = time
        
    }
    
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */



}
