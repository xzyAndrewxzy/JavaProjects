//
//  ViewController.swift
//  TrackerHours
//
//  Created by user145527 on 12/3/18.
//  Copyright © 2018 user145527. All rights reserved.
//

import UIKit
import Firebase
class ViewController: UIViewController {


    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passWordTexField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


    @IBAction func loginButton(_ sender: Any) {

        Auth.auth().signIn(withEmail: emailTextField.text!, password: passWordTexField.text!) { (user, error) in
            if error != nil {
                print(error!)

            }else{
                print("login Pass")
             
                if let goToHours = self.storyboard?.instantiateViewController(withIdentifier: "idToHours") as? HoursViewController{
                   
                    goToHours.dateArray = ["test","data","passed"]
                    self.present(goToHours, animated: true)
                    
                }
               
                
                //self.performSegue(withIdentifier: "passToHours", sender: self)
            }

        }
        
    }






    @IBAction func registerButton(_ sender: AnyObject) {

        performSegue(withIdentifier: "passToRegister", sender: self)

    }


    
}

