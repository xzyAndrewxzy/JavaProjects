import javafx.application.Application;

import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.layout.Pane;

public class MyCircleDiver extends Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		
		MyCircle aCircle = new MyCircle();
		
		MyCircle redCircle, blueCircle;
		
		MyCircle[] arrayCircles = new MyCircle[10];
			redCircle= new MyCircle(50,100,30, Color.RED);
			
			blueCircle  = new MyCircle(100,100,20,Color.BLUE);
			
			EnhancedMyCircle redGreenCircle = new EnhancedMyCircle(200,100,10, Color.BISQUE,50,Color.GREEN,Color.DEEPSKYBLUE);
			
			MyCircle[] arrayCircles2 = new MyCircle[3];
			
			arrayCircles2[0] = redCircle;
			arrayCircles2[1] = blueCircle;
			arrayCircles2[2] = redGreenCircle;
			
			
			for (int i = 0; i < arrayCircles2.length;i++) {
				
				System.out.printf(" %5.2f\n", arrayCircles2[i].findArea() );
				// prints arrayCircles2 containing findArea Method
			}
			
			
			
			for (int i = 0; i < arrayCircles.length;i++) { // creates circles 
				
				arrayCircles[i] = new MyCircle(60,10 + 60 * i, 20, Color.BISQUE); // why doesnt it have MyCircle at begining
			}
			
			
				System.out.printf("the area of the red Circles is %f \n ", redCircle.findArea() );
				
				
				System.out.printf("the area of the blue Circles is %f \n ", blueCircle.findArea() );
				
				
				System.out.printf("the area of the aCircles is %f \n ", aCircle.findArea() );
				
				System.out.println(redCircle);
				
				
				System.out.printf("radius of redCircle is %d \n  ", redCircle.getRadius() );
				
				// creates drawing ?
				Pane pane = new Pane();
				
				redCircle.drawCircle(pane);
				
				blueCircle.drawCircle(pane);
				
				aCircle.drawCircle(pane);
				
				
				for (int i = 0 ; i < arrayCircles.length; i++) {
					
					arrayCircles[i].drawCircle(pane);
		
				}
				
				MyCircle array2DCircles[][] = new MyCircle[5][5];
				
				for (int row = 0; row< array2DCircles.length; row++) {
						
				for(int col = 0; col < array2DCircles[row].length; col++) {
					array2DCircles[row][col] = new MyCircle((col +1 )* 30 + 80, (row+1) * 30 + 50, 15, Color.LIGHTCORAL);
					
					array2DCircles[row][col].drawCircle(pane);
					
					
					
					
					
				}		// end of col loop
						
						
				
	}// end of row loop
		
				
				Scene scene = new Scene(pane,400,450); // width 400, height 450
				
				primaryStage.setTitle(" MyCircle Objects");
				
				primaryStage.setScene(scene);
				
				primaryStage.show();
				
				
				
	}// end of start method
					
		
	}// end of MydriverClass


