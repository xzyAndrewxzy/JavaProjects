import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;



public class EnhancedMyCircle extends MyCircle {

	private float circumference;
	private Color borderColor;
	private Color chordColor;
	
	public EnhancedMyCircle(Color borderColor, Color chordColor) { // is this initating the receving borderColor into self.borderColor
		super(); // calls the superclass constructor
		this.borderColor = borderColor;
		this.chordColor = chordColor;
	} // end of constructor 

	// -- explain what top is doing and why isnt it default, why is bottom default if missing circumference
	
	public EnhancedMyCircle() { // are default call with no -> parameters()
		super();
		this.borderColor = Color.GREEN;
		this.chordColor = Color.BLACK;
		
		
	}// end of default constructor 

	public EnhancedMyCircle(int x, int y , int radius, Color circleColor,
			float circumference, Color borderColor, Color chordColor) {
		
		super( x, y, radius, circleColor); // calls from superclass : myCircle
		this.circumference = circumference;
		this.borderColor = borderColor;
		this.chordColor = chordColor;
		
	}// end of constructor
	
	
	public float computeCircumference() {
		circumference = 2 * PI * radius;
		return circumference;
		
		
	}//end of computeCircumference method

	@Override
	public String toString() {
		return "EnhancedMyCircle [circumference=" + circumference + ", borderColor=" + borderColor + ", chordColor="
				+ chordColor + "]";
	}// end of toString method
	
	
	public void drawRadiusOnCircle ( Pane p ) {
		Circle circle = new Circle(x+10 , y +10,radius +5);
		
		circle.setFill(borderColor); // adds features to circle
		
		p.getChildren().add(circle); // prints circle to pane | creates
		
		super.drawCircle(p); // call the superclass drawCircle method
		
	}
	
	
	public void drawCircle(Pane p) {
		// override the drawCircle method the superclass mycircle
		super.drawCircle(p);
		
		Line line1 = new Line(x,y, x - radius, y - radius);
		
		line1.setStroke(chordColor);	// = setFill
		
		p.getChildren().add(line1); // p = Pane | creates 
		
		
	}// end of overrider drawCircle
	
	
	
	
	
	
	
	
} // end of EnhancedMyCircle
