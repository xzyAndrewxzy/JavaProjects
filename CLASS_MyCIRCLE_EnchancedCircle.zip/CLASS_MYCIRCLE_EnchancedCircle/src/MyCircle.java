import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.layout.Pane;

// does this has to be called becasuse of methods called from driver 

public class MyCircle extends Object { // where is object coming from? is it calling from java internal library
	
	protected Color circleColor;
	protected int x , y, radius;
	protected static int numberCircles = 0 ;
	protected static final float PI = 3.14159f;
	
	public MyCircle() {
		numberCircles ++;
		x = 40;
		y = 50;
		radius = 8;
		circleColor = javafx.scene.paint.Color.AQUAMARINE;
		
		
	}//default 

	public MyCircle(int x, int y, int radius, Color circleColor) {
		
		this.circleColor = circleColor;
		this.x = x;
		this.y = y;
		this.radius = radius;
	}// overloaded constructor

	public MyCircle(int x, int y) { // convert to setX(), explain if setX(fromDriver) -> call getX from holder to grab to use in x in holder
		numberCircles ++;
		this.x = x;
		this.y = y;
		radius = 8;
		circleColor = Color.AQUAMARINE;
	}//overloaded constructor

	public MyCircle(int radius) {
		numberCircles ++;
		this.x = 80;
		this.y = 100;
		this.radius = radius;
		//setRadius(radius);
		circleColor = Color.ORANGE;
				
		this.radius = radius;
	}// overloaded constructor

	
	// getter and setters 
	
	public Color getCircleColor() {
		return circleColor;
	}

	public void setCircleColor(Color circleColor) {
		this.circleColor = circleColor;
	}
  
	public int getX() {
		return x;
	}

	public void setX(int x) { // is it void to prevent from manipulating value received?
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}

	public static int getNumberCircles() {
		return numberCircles;
	}
	// End of getters and setters

	
	@Override
	public String toString() {
		return "MyCircle [circleColor=" + circleColor + ", x=" + x + ", y=" + y + ", radius = " + radius + "]";
	}
	
	
	public float findArea() {
		
		float area;
		area = PI * radius * radius;
		
		return area;
		
	}// end of findArea
	
	
	public void drawCircle(Pane p) { // is this from driver Circle?
		
		Circle c1 = new Circle(x,y,radius); // is it a library method? or called from driver
		
		c1.setFill(circleColor);
		p.getChildren().add(c1);
		
		
	}// end of drawCircle
	
	private float circumference;
	
	private void computedCircumference() {
		
		circumference = 2 * PI * radius ;
		
	}	
	
	
	
	
	

}
