
public class ConrolNestedLoops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for( int outer =1; outer <=5; outer++) {
			for( int inner = 1; inner <= 10; inner ++) {
				System.out.printf(" outer = %d   inner = %d \n", outer , inner);
				
			}// end of inner   ** inner loop must finish before next outer loop number to come
		}// end of outter loop  Ex outer 2 | inner 1 - 10
				
	}

}
