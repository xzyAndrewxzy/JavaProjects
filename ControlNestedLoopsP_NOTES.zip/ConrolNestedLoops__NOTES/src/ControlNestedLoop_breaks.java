
public class ControlNestedLoop_breaks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for( int outer =1; outer <=7; outer++) {
			for( int inner = 1; inner <= 10; inner ++) {
				System.out.printf("* outer = %d   inner = %d \n", outer , inner);
				
				System.out.println("");
				
				if( (outer + inner)> 7) {
					
					System.out.println("BREAK STATEMENT WILL EXECUTE");
					break; //  WHEN IT HITS BREASK IT WILL BREAK OUT OF INNER LOOP
					//	GO TO NEXT ITERATION OF OUTER
					
				}// end of IF with break
				
				System.out.println("After Break");
				System.out.printf("BREAK~ outer = %d   inner = %d \n", outer , inner);
				
			}// end of inner   ** inner loop must finish before next outer loop number to come
		}// end of outter loop  Ex outer 2 | inner 1 - 10
				
	
		System.out.println("\n \n \n LOOP WITH CONTINUE ");
		
		for( int outer =1; outer <=7; outer++) {
			for( int inner = 1; inner <= 10; inner ++) {
				System.out.printf("* outer = %d   inner = %d \n", outer , inner);
				
				System.out.println("");
				
				if( (outer + inner)> 7) {
					
					System.out.println("CONTINUE STATEMENT WILL EXECUTE");
					continue; // CONTINUES THE NEXT ITERATION OF THE INNER LOOP
					// ITS SKIPS ALL THE CODE UNDER CONTINUE THATS INSIDE INNER LOOP 
					
					
					
				}// end of IF with CONTINUE
				//CODE THAT IS SKIPPED
				
				System.out.println("After CONTINUE");
				System.out.printf("CONTINUE	~ outer = %d   inner = %d \n", outer , inner);
				
			}// end of inner   ** inner loop must finish before next outer loop number to come
		}// end of outter loop  Ex outer 2 | inner 1 - 10
		
		
		System.out.println("\n \n \n CONTINUE LOOP WITH LABEL ");
		
		P1: for( int outer =1; outer <=7; outer++) {
			for( int inner = 1; inner <= 10; inner ++) {
				System.out.printf("* outer = %d   inner = %d \n", outer , inner);
				
				System.out.println("");
				
				if( (outer + inner)> 7) {
					
					System.out.println("CONTINUE STATEMENT WILL EXECUTE");
					continue P1; // GOES TO THE STATEMENT WITH THE P1 LABEL
					// STARTS NEXT INTERATION OF OUTER LOOP
					
					
					
				}// end of IF with CONTINUE
				//CODE THAT IS SKIPPED
				
				System.out.println("After CONTINUE _with label");
				System.out.printf("CONTINUE ~ outer = %d   inner = %d \n", outer , inner);
				
			}// end of inner   ** inner loop must finish before next outer loop number to come
		}// end of outter loop  Ex outer 2 | inner 1 - 10
	
	}

}


// Do while loop

//do {
//	excutable code
//}while("condition");


