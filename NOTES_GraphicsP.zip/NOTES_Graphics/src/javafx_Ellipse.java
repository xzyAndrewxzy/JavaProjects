import javafx.application.Application;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class javafx_Ellipse extends Application{

	public static void main(String[] args) {
			// TODO Auto-generated method stub
			Application.launch(args);
		}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		Pane pane = new Pane();
		Scene scene = new Scene(pane,500,600);
		primaryStage.setTitle("JavaFx");
		primaryStage.setScene(scene);
		primaryStage.show();
			
			
		Ellipse e1 = new Ellipse(250,250,200,100);
		e1.setFill(Color.color(0, 1.0, 0));	
		pane.getChildren().add(e1);	
			
			
	}

}