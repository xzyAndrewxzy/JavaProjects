import javafx.application.Application;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class javafx_CircleandLine extends Application{

	public static void main(String[] args) {
			// TODO Auto-generated method stub
			Application.launch(args);
		}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		Pane pane = new Pane();
		
		Scene scene = new Scene(pane,500,600);
		primaryStage.setTitle("JavaFx");
		primaryStage.setScene(scene);
		primaryStage.show();
			
		for(int i =0; i <16;i++) {
			
// MARK: Func that adds ellipse			
		Ellipse e1 = new Ellipse(250,250,200,100);
		e1.setFill(Color.color(Math.random(), Math.random(), Math.random()));// - affects color
		
		e1.setRotate(i*940/16); // - rotates ellipse 940
		
		pane.getChildren().add(e1);	
		
		}	// end of loop
		
// MARK: Func that adds line			
		Line line1 = new Line(0,0,500,600);
		line1.setStroke(Color.BLUEVIOLET);
		line1.setStrokeWidth(3);
		pane.getChildren().add(line1);
		
// MARK: Functhat add Circle
		Circle c1 = new Circle(100,150,10); // X,Y,Diamter
		c1.setFill(Color.color(Math.random(), Math.random(), Math.random()));
		c1.setStroke(Color.KHAKI);
		c1.setStrokeWidth(5);
		pane.getChildren().add(c1);
	}// end of start

}// end of main