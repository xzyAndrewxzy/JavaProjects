
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class javafx_Polygon2 extends Application{

	public static void main(String[] args) {
			// TODO Auto-generated method stub
			Application.launch(args);
		}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		Pane pane = new Pane();
		
		Scene scene = new Scene(pane,500,600);
		
		primaryStage.setTitle("JavaFx");
		primaryStage.setScene(scene);
		primaryStage.show();
			
		for(int i =0; i <16;i++) {
			
// MARK: Func that adds ellipse			
		Ellipse e1 = new Ellipse(250,250,200,100);
		e1.setFill(Color.color(Math.random(), Math.random(), Math.random()));// - affects color
		
		e1.setRotate(i*940/16); // - rotates ellipse
		
		pane.getChildren().add(e1);	
		
		}	// end of loop
		
// MARK: Func that adds line			
		Line line1 = new Line(0,0,500,600);
		line1.setStroke(Color.BLUEVIOLET);
		line1.setStrokeWidth(3);
		pane.getChildren().add(line1);
		
// MARK: Functhat add Circle
		Circle c1 = new Circle(100,150,10); // X,Y,Diamter
		c1.setFill(Color.color(Math.random(), Math.random(), Math.random()));
		c1.setStroke(Color.KHAKI);
		c1.setStrokeWidth(5);
		pane.getChildren().add(c1);

// MARK : Func Rectangle 	
		Rectangle r1 = new Rectangle(300,300,110,50); // X,Y, length,width
		r1.setFill(Color.BLUE);
		r1.setStroke(Color.RED);
		r1.setStrokeWidth(5);
		pane.getChildren().add(r1);

//MARK : Func Arch		
		Arc a1 = new Arc(250,200,120,100,180,300);
		a1.setFill(Color.YELLOW);
		a1.setStroke(Color.GOLD);
		
		a1.setType(ArcType.ROUND); // - sets type of arc
		
		a1.setStrokeWidth(3);
		pane.getChildren().add(a1);

// MARK : Polygon
		Polygon poly = new Polygon();
		poly.setFill(Color.CADETBLUE);
		
		ObservableList<Double> list = poly.getPoints();
		// method used to add points
		list.add(250.0);// x1
		list.add(400.0);// y1
		list.add(350.0);// x2
		list.add(500.0);// y2
		list.add(140.0);// x3
		list.add(500.0);// y3
		
		pane.getChildren().add(poly);
		
// MARK: Polygon2
		Polygon poly2 = new Polygon();
		ObservableList<Double> list2 = poly2.getPoints();// -connected
		final double WIDTH = 200;
		final double HEIGHT = 100;
		double centerX = WIDTH /2;
		double centerY = HEIGHT/2;
		
		double radius = Math.min(WIDTH, HEIGHT) * 0.4;
		
		poly2.setStroke(Color.DARKCYAN);
		poly2.setStrokeWidth(3);
		poly2.setFill(Color.SLATEGREY);
		
	for(int i =0; i < 6; i++) {
		list2.add(centerX + 200 + radius * Math.cos(2*i*Math.PI/6));//-connected
		list2.add(centerY + 200 + radius * Math.sin(2*i*Math.PI/6));// - connected
		
		}
		
		pane.getChildren().add(poly2);
		
	}// end of start
}	
